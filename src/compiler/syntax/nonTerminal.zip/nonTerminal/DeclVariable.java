package compiler.syntax.nonTerminal;

import compiler.semantic.symbol.SymbolVariable;
import es.uned.lsi.compiler.semantic.type.TypeIF;

/**
 * Clase que representa una declaración de variable en el compilador AdaUNED.
 * Contiene la información del símbolo y del tipo asociado a la variable
 * declarada.
 * 
 * Autor: Eduardo Garcia Romera
 * Email: egarcia3266@alumno.uned.es
 * DNI: 54487155V
 * Versión: 1.0
 */
public class DeclVariable extends NonTerminal {

    /** Símbolo de la variable declarada */
    private SymbolVariable symbol;

    /** Tipo de la variable declarada */
    private TypeIF type;

    /** Constructor por defecto */
    public DeclVariable() {
        super();
    }

    /**
     * Constructor con parámetros
     * 
     * @param symbol símbolo de la variable
     * @param type   tipo de la variable
     */
    public DeclVariable(SymbolVariable symbol, TypeIF type) {
        super();
        this.symbol = symbol;
        this.type = type;
    }

    /**
     * Constructor de copia
     * 
     * @param other otra instancia de DeclVariable
     */
    public DeclVariable(DeclVariable other) {
        super();
        this.symbol = other.symbol;
        this.type = other.type;
    }

    public SymbolVariable getSymbol() {
        return symbol;
    }

    public void setSymbol(SymbolVariable symbol) {
        this.symbol = symbol;
    }

    public TypeIF getType() {
        return type;
    }

    public void setType(TypeIF type) {
        this.type = type;
    }
}
