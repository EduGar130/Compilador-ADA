package compiler.syntax.nonTerminal;

import compiler.semantic.symbol.SymbolProcedure;

/**
 * Clase que representa una declaración de procedimiento en el compilador
 * AdaUNED.
 * Contiene el símbolo del procedimiento declarado.
 * 
 * Autor: Eduardo Garcia Romera
 * Email: egarcia3266@alumno.uned.es
 * DNI: 54487155V
 * Versión: 1.0
 */
public class DeclProcedimiento extends NonTerminal {

    /** Símbolo del procedimiento */
    private SymbolProcedure symbol;

    /** Constructor por defecto */
    public DeclProcedimiento() {
        super();
    }

    /**
     * Constructor con parámetros
     * 
     * @param symbol símbolo del procedimiento
     */
    public DeclProcedimiento(SymbolProcedure symbol) {
        super();
        this.symbol = symbol;
    }

    /**
     * Constructor de copia
     * 
     * @param other otra instancia de DeclProcedimiento
     */
    public DeclProcedimiento(DeclProcedimiento other) {
        super();
        this.symbol = other.symbol;
    }

    public SymbolProcedure getSymbol() {
        return symbol;
    }

    public void setSymbol(SymbolProcedure symbol) {
        this.symbol = symbol;
    }
}
