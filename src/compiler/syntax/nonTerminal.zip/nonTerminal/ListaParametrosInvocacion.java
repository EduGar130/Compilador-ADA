package compiler.syntax.nonTerminal;

import java.util.ArrayList;
import java.util.List;
import es.uned.lsi.compiler.intermediate.TemporalIF;

/**
 * Clase que representa una lista de parámetros en una invocación (call) en el
 * compilador AdaUNED.
 * Contiene los temporales que almacenan los valores de cada parámetro evaluado.
 * 
 * Autor: Eduardo Garcia Romera
 * Email: egarcia3266@alumno.uned.es
 * DNI: 54487155V
 * Versión: 1.0
 */
public class ListaParametrosInvocacion extends NonTerminal {

    /** Lista de temporales evaluados para los parámetros */
    private List<TemporalIF> temporales;

    /** Constructor por defecto */
    public ListaParametrosInvocacion() {
        super();
        this.temporales = new ArrayList<>();
    }

    /**
     * Constructor con lista de temporales
     * 
     * @param temporales lista de temporales
     */
    public ListaParametrosInvocacion(List<TemporalIF> temporales) {
        super();
        this.temporales = temporales;
    }

    /**
     * Constructor de copia
     * 
     * @param other otra instancia de ListaParametrosInvocacion
     */
    public ListaParametrosInvocacion(ListaParametrosInvocacion other) {
        super();
        this.temporales = new ArrayList<>(other.temporales);
    }

    public List<TemporalIF> getTemporales() {
        return temporales;
    }

    public void setTemporales(List<TemporalIF> temporales) {
        this.temporales = temporales;
    }

    /**
     * Añade un temporal a la lista de parámetros
     * 
     * @param temporal temporal evaluado
     */
    public void addTemporal(TemporalIF temporal) {
        this.temporales.add(temporal);
    }
}
