package compiler.syntax.nonTerminal;

/**
 * Clase que representa la declaración de parámetros de un subprograma.
 * 
 * Autor: Eduardo Garcia Romera
 * Email: egarcia3266@alumno.uned.es
 * DNI: 54487155V
 * Versión: 1.0
 */
public class DeclParametros extends NonTerminal {

    public DeclParametros() {
        super();
    }

    public DeclParametros(DeclParametros other) {
        super();
    }
}
