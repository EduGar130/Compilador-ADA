package compiler.syntax.nonTerminal;

/**
 * Clase que representa un operador lógico en el compilador AdaUNED.
 * Contiene el símbolo del operador lógico (ej: and, or, not).
 * 
 * Autor: Eduardo Garcia Romera
 * Email: egarcia3266@alumno.uned.es
 * DNI: 54487155V
 * Versión: 1.0
 */
public class OperadorLogico extends NonTerminal {

    /** Símbolo del operador lógico */
    private String operador;

    /** Constructor por defecto */
    public OperadorLogico() {
        super();
    }

    /**
     * Constructor con símbolo
     * 
     * @param operador símbolo del operador lógico
     */
    public OperadorLogico(String operador) {
        super();
        this.operador = operador;
    }

    /**
     * Constructor de copia
     * 
     * @param other otra instancia de OperadorLogico
     */
    public OperadorLogico(OperadorLogico other) {
        super();
        this.operador = other.operador;
    }

    public String getOperador() {
        return operador;
    }

    public void setOperador(String operador) {
        this.operador = operador;
    }
}
