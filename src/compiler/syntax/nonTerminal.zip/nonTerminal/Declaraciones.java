package compiler.syntax.nonTerminal;

/**
 * Clase que representa el bloque de declaraciones globales del programa en el
 * compilador AdaUNED.
 * Agrupa constantes, tipos, variables y subprogramas en el orden definido por
 * la gramática.
 * 
 * Autor: Eduardo Garcia Romera
 * Email: egarcia3266@alumno.uned.es
 * DNI: 54487155V
 * Versión: 1.0
 */
public class Declaraciones extends NonTerminal {

    /** Constructor por defecto */
    public Declaraciones() {
        super();
    }

    /**
     * Constructor de copia
     * 
     * @param other otra instancia de Declaraciones
     */
    public Declaraciones(Declaraciones other) {
        super();
    }
}
