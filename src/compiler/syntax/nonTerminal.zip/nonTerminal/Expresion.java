package compiler.syntax.nonTerminal;

import es.uned.lsi.compiler.semantic.type.TypeIF;
import es.uned.lsi.compiler.intermediate.TemporalIF;

/**
 * Clase que representa una expresión evaluable en el compilador AdaUNED.
 * Puede ser una operación aritmética, relacional, lógica, un literal, o una
 * invocación a función.
 * 
 * Contiene su tipo semántico y el temporal donde se almacena su valor
 * intermedio.
 * 
 * Autor: Eduardo Garcia Romera
 * Email: egarcia3266@alumno.uned.es
 * DNI: 54487155V
 * Versión: 1.0
 */
public class Expresion extends NonTerminal {

    /** Tipo resultante de la expresión */
    private TypeIF type;

    /** Temporal que contiene el valor de la expresión */
    private TemporalIF temporal;

    /** Constructor por defecto */
    public Expresion() {
        super();
    }

    /**
     * Constructor con tipo y temporal
     * 
     * @param type     tipo de la expresión
     * @param temporal temporal que representa su valor
     */
    public Expresion(TypeIF type, TemporalIF temporal) {
        super();
        this.type = type;
        this.temporal = temporal;
    }

    /**
     * Constructor de copia
     * 
     * @param other otra instancia de Expresion
     */
    public Expresion(Expresion other) {
        super();
        this.type = other.type;
        this.temporal = other.temporal;
    }

    public TypeIF getType() {
        return type;
    }

    public void setType(TypeIF type) {
        this.type = type;
    }

    public TemporalIF getTemporal() {
        return temporal;
    }

    public void setTemporal(TemporalIF temporal) {
        this.temporal = temporal;
    }
}
