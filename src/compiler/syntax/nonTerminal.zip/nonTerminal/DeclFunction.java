package compiler.syntax.nonTerminal;

import compiler.semantic.symbol.SymbolFunction;
import es.uned.lsi.compiler.semantic.type.TypeIF;

/**
 * Clase que representa una declaración de función en el compilador AdaUNED.
 * Contiene el símbolo de la función y su tipo de retorno.
 * 
 * Autor: Eduardo Garcia Romera
 * Email: egarcia3266@alumno.uned.es
 * DNI: 54487155V
 * Versión: 1.0
 */
public class DeclFunction extends NonTerminal {

    /** Símbolo de la función */
    private SymbolFunction symbol;

    /** Tipo de retorno de la función */
    private TypeIF returnType;

    /** Constructor por defecto */
    public DeclFunction() {
        super();
    }

    /**
     * Constructor con parámetros
     * 
     * @param symbol     símbolo de la función
     * @param returnType tipo de retorno
     */
    public DeclFunction(SymbolFunction symbol, TypeIF returnType) {
        super();
        this.symbol = symbol;
        this.returnType = returnType;
    }

    /**
     * Constructor de copia
     * 
     * @param other otra instancia de DeclFunction
     */
    public DeclFunction(DeclFunction other) {
        super();
        this.symbol = other.symbol;
        this.returnType = other.returnType;
    }

    public SymbolFunction getSymbol() {
        return symbol;
    }

    public void setSymbol(SymbolFunction symbol) {
        this.symbol = symbol;
    }

    public TypeIF getReturnType() {
        return returnType;
    }

    public void setReturnType(TypeIF returnType) {
        this.returnType = returnType;
    }
}
