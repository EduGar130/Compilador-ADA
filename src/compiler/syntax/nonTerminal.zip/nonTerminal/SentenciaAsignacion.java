package compiler.syntax.nonTerminal;

import es.uned.lsi.compiler.semantic.symbol.SymbolIF;
import es.uned.lsi.compiler.semantic.type.TypeIF;

/**
 * Clase que representa una sentencia de asignación en el compilador AdaUNED.
 * Contiene la referencia izquierda (LHS) y la expresión derecha (RHS).
 * 
 * Autor: Eduardo Garcia Romera
 * Email: egarcia3266@alumno.uned.es
 * DNI: 54487155V
 * Versión: 1.0
 */
public class SentenciaAsignacion extends NonTerminal {

    /** Símbolo de la referencia izquierda */
    private SymbolIF refSymbol;

    /** Tipo del valor asignado */
    private TypeIF type;

    /** Constructor por defecto */
    public SentenciaAsignacion() {
        super();
    }

    /**
     * Constructor con símbolo de referencia y tipo
     * 
     * @param refSymbol símbolo al que se asigna
     * @param type      tipo de la expresión asignada
     */
    public SentenciaAsignacion(SymbolIF refSymbol, TypeIF type) {
        super();
        this.refSymbol = refSymbol;
        this.type = type;
    }

    /**
     * Constructor de copia
     * 
     * @param other otra instancia de SentenciaAsignacion
     */
    public SentenciaAsignacion(SentenciaAsignacion other) {
        super();
        this.refSymbol = other.refSymbol;
        this.type = other.type;
    }

    public SymbolIF getRefSymbol() {
        return refSymbol;
    }

    public void setRefSymbol(SymbolIF refSymbol) {
        this.refSymbol = refSymbol;
    }

    public TypeIF getType() {
        return type;
    }

    public void setType(TypeIF type) {
        this.type = type;
    }
}
