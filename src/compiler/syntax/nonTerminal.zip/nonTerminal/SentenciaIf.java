package compiler.syntax.nonTerminal;

import es.uned.lsi.compiler.intermediate.TemporalIF;

/**
 * Clase que representa una sentencia condicional IF en el compilador AdaUNED.
 * Contiene el temporal que representa la condición evaluada.
 * 
 * Autor: Eduardo Garcia Romera
 * Email: egarcia3266@alumno.uned.es
 * DNI: 54487155V
 * Versión: 1.0
 */
public class SentenciaIf extends NonTerminal {

    /** Temporal que representa el resultado de la condición */
    private TemporalIF condicion;

    /** Constructor por defecto */
    public SentenciaIf() {
        super();
    }

    /**
     * Constructor con temporal de condición
     * 
     * @param condicion temporal resultante de la evaluación condicional
     */
    public SentenciaIf(TemporalIF condicion) {
        super();
        this.condicion = condicion;
    }

    /**
     * Constructor de copia
     * 
     * @param other otra instancia de SentenciaIf
     */
    public SentenciaIf(SentenciaIf other) {
        super();
        this.condicion = other.condicion;
    }

    public TemporalIF getCondicion() {
        return condicion;
    }

    public void setCondicion(TemporalIF condicion) {
        this.condicion = condicion;
    }
}
