package compiler.syntax.nonTerminal;

import compiler.semantic.symbol.SymbolParameter;
import es.uned.lsi.compiler.semantic.type.TypeIF;

/**
 * Clase que representa una declaración de parámetro en el compilador AdaUNED.
 * Contiene el símbolo del parámetro y su tipo.
 * 
 * Autor: Eduardo Garcia Romera
 * Email: egarcia3266@alumno.uned.es
 * DNI: 54487155V
 * Versión: 1.0
 */
public class DeclParametro extends NonTerminal {

    /** Símbolo del parámetro */
    private SymbolParameter symbol;

    /** Tipo del parámetro */
    private TypeIF type;

    /** Constructor por defecto */
    public DeclParametro() {
        super();
    }

    /**
     * Constructor con parámetros
     * 
     * @param symbol símbolo del parámetro
     * @param type   tipo del parámetro
     */
    public DeclParametro(SymbolParameter symbol, TypeIF type) {
        super();
        this.symbol = symbol;
        this.type = type;
    }

    /**
     * Constructor de copia
     * 
     * @param other otra instancia de DeclParametro
     */
    public DeclParametro(DeclParametro other) {
        super();
        this.symbol = other.symbol;
        this.type = other.type;
    }

    public SymbolParameter getSymbol() {
        return symbol;
    }

    public void setSymbol(SymbolParameter symbol) {
        this.symbol = symbol;
    }

    public TypeIF getType() {
        return type;
    }

    public void setType(TypeIF type) {
        this.type = type;
    }
}
