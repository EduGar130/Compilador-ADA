package compiler.syntax.nonTerminal;

import es.uned.lsi.compiler.intermediate.TemporalIF;

/**
 * Clase que representa una sentencia de bucle WHILE en el compilador AdaUNED.
 * Contiene el temporal asociado a la condición evaluada.
 * 
 * Autor: Eduardo Garcia Romera
 * Email: egarcia3266@alumno.uned.es
 * DNI: 54487155V
 * Versión: 1.0
 */
public class SentenciaWhile extends NonTerminal {

    /** Temporal que representa la condición del bucle */
    private TemporalIF condicion;

    /** Constructor por defecto */
    public SentenciaWhile() {
        super();
    }

    /**
     * Constructor con temporal de condición
     * 
     * @param condicion temporal evaluado como condición del bucle
     */
    public SentenciaWhile(TemporalIF condicion) {
        super();
        this.condicion = condicion;
    }

    /**
     * Constructor de copia
     * 
     * @param other otra instancia de SentenciaWhile
     */
    public SentenciaWhile(SentenciaWhile other) {
        super();
        this.condicion = other.condicion;
    }

    public TemporalIF getCondicion() {
        return condicion;
    }

    public void setCondicion(TemporalIF condicion) {
        this.condicion = condicion;
    }
}
