package compiler.syntax.nonTerminal;

/**
 * Clase que representa las declaraciones locales de una función en el
 * compilador AdaUNED.
 * Incluye constantes, tipos, variables y subprogramas declarados dentro del
 * cuerpo.
 * 
 * Autor: Eduardo Garcia Romera
 * Email: egarcia3266@alumno.uned.es
 * DNI: 54487155V
 * Versión: 1.0
 */
public class DeclaracionesFunction extends NonTerminal {

    /** Constructor por defecto */
    public DeclaracionesFunction() {
        super();
    }

    /**
     * Constructor de copia
     * 
     * @param other otra instancia de DeclaracionesFunction
     */
    public DeclaracionesFunction(DeclaracionesFunction other) {
        super();
    }
}
