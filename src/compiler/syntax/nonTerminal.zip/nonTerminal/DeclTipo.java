package compiler.syntax.nonTerminal;

import es.uned.lsi.compiler.semantic.type.TypeIF;

/**
 * Clase que representa una declaración de tipo definido por el usuario.
 * 
 * Autor: Eduardo Garcia Romera
 * Email: egarcia3266@alumno.uned.es
 * DNI: 54487155V
 * Versión: 1.0
 */
public class DeclTipo extends NonTerminal {

    private TypeIF type;

    public DeclTipo() {
        super();
    }

    public DeclTipo(TypeIF type) {
        super();
        this.type = type;
    }

    public DeclTipo(DeclTipo other) {
        super();
        this.type = other.type;
    }

    public TypeIF getType() {
        return type;
    }

    public void setType(TypeIF type) {
        this.type = type;
    }
}
