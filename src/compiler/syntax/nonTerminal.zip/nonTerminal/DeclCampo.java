package compiler.syntax.nonTerminal;

import compiler.semantic.symbol.SymbolVariable;
import es.uned.lsi.compiler.semantic.type.TypeIF;

/**
 * Clase que representa una declaración de campo dentro de un registro en el
 * compilador AdaUNED.
 * Cada campo es una variable con su propio tipo.
 * 
 * Autor: Eduardo Garcia Romera
 * Email: egarcia3266@alumno.uned.es
 * DNI: 54487155V
 * Versión: 1.0
 */
public class DeclCampo extends NonTerminal {

    /** Símbolo del campo (como variable) */
    private SymbolVariable symbol;

    /** Tipo del campo */
    private TypeIF type;

    /** Constructor por defecto */
    public DeclCampo() {
        super();
    }

    /**
     * Constructor con parámetros
     * 
     * @param symbol símbolo del campo
     * @param type   tipo del campo
     */
    public DeclCampo(SymbolVariable symbol, TypeIF type) {
        super();
        this.symbol = symbol;
        this.type = type;
    }

    /**
     * Constructor de copia
     * 
     * @param other otra instancia de DeclCampo
     */
    public DeclCampo(DeclCampo other) {
        super();
        this.symbol = other.symbol;
        this.type = other.type;
    }

    public SymbolVariable getSymbol() {
        return symbol;
    }

    public void setSymbol(SymbolVariable symbol) {
        this.symbol = symbol;
    }

    public TypeIF getType() {
        return type;
    }

    public void setType(TypeIF type) {
        this.type = type;
    }
}
