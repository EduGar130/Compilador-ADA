package compiler.syntax.nonTerminal;

import es.uned.lsi.compiler.intermediate.TemporalIF;

/**
 * Clase que representa una sentencia put_line en el compilador AdaUNED.
 * Contiene el temporal que representa el valor que se va a imprimir.
 * 
 * Autor: Eduardo Garcia Romera
 * Email: egarcia3266@alumno.uned.es
 * DNI: 54487155V
 * Versión: 1.0
 */
public class SentenciaPutLine extends NonTerminal {

    /** Temporal con el valor a imprimir */
    private TemporalIF temporal;

    /** Constructor por defecto */
    public SentenciaPutLine() {
        super();
    }

    /**
     * Constructor con temporal
     * 
     * @param temporal valor a imprimir
     */
    public SentenciaPutLine(TemporalIF temporal) {
        super();
        this.temporal = temporal;
    }

    /**
     * Constructor de copia
     * 
     * @param other otra instancia
     */
    public SentenciaPutLine(SentenciaPutLine other) {
        super();
        this.temporal = other.temporal;
    }

    public TemporalIF getTemporal() {
        return temporal;
    }

    public void setTemporal(TemporalIF temporal) {
        this.temporal = temporal;
    }
}
