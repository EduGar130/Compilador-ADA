package compiler.syntax.nonTerminal;

import compiler.semantic.symbol.SymbolProcedure;
import java.util.List;
import es.uned.lsi.compiler.intermediate.TemporalIF;

/**
 * Clase que representa una llamada a un procedimiento en el compilador AdaUNED.
 * Contiene el símbolo del procedimiento y una lista de temporales para los
 * parámetros.
 * 
 * Autor: Eduardo Garcia Romera
 * Email: egarcia3266@alumno.uned.es
 * DNI: 54487155V
 * Versión: 1.0
 */
public class SentenciaProcedimiento extends NonTerminal {

    /** Símbolo del procedimiento invocado */
    private SymbolProcedure symbol;

    /** Temporales con los valores de los parámetros */
    private List<TemporalIF> parametros;

    /** Constructor por defecto */
    public SentenciaProcedimiento() {
        super();
    }

    /**
     * Constructor con símbolo y parámetros
     * 
     * @param symbol     símbolo del procedimiento
     * @param parametros lista de temporales como parámetros
     */
    public SentenciaProcedimiento(SymbolProcedure symbol, List<TemporalIF> parametros) {
        super();
        this.symbol = symbol;
        this.parametros = parametros;
    }

    /**
     * Constructor de copia
     * 
     * @param other otra instancia de SentenciaProcedimiento
     */
    public SentenciaProcedimiento(SentenciaProcedimiento other) {
        super();
        this.symbol = other.symbol;
        this.parametros = other.parametros;
    }

    public SymbolProcedure getSymbol() {
        return symbol;
    }

    public void setSymbol(SymbolProcedure symbol) {
        this.symbol = symbol;
    }

    public List<TemporalIF> getParametros() {
        return parametros;
    }

    public void setParametros(List<TemporalIF> parametros) {
        this.parametros = parametros;
    }
}
