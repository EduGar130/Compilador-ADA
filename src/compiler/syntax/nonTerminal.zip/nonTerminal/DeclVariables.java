package compiler.syntax.nonTerminal;

import java.util.ArrayList;
import java.util.List;
import compiler.semantic.symbol.SymbolVariable;

/**
 * Clase que representa una declaración de múltiples variables en el compilador
 * AdaUNED.
 * 
 * Autor: Eduardo Garcia Romera
 * Email: egarcia3266@alumno.uned.es
 * DNI: 54487155V
 * Versión: 1.0
 */
public class DeclVariables extends NonTerminal {

    /** Lista de símbolos de las variables declaradas */
    private List<SymbolVariable> variables;

    public DeclVariables() {
        super();
        this.variables = new ArrayList<>();
    }

    public DeclVariables(List<SymbolVariable> variables) {
        super();
        this.variables = variables;
    }

    public DeclVariables(DeclVariables other) {
        super();
        this.variables = new ArrayList<>(other.variables);
    }

    public List<SymbolVariable> getVariables() {
        return variables;
    }

    public void setVariables(List<SymbolVariable> variables) {
        this.variables = variables;
    }

    public void addVariable(SymbolVariable variable) {
        this.variables.add(variable);
    }
}
