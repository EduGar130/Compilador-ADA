package compiler.syntax.nonTerminal;

/**
 * Clase base para representar cualquier tipo de sentencia en el compilador
 * AdaUNED.
 * Esta clase puede ser extendida o contenida por otras estructuras como
 * Sentencias.
 * 
 * Autor: Eduardo Garcia Romera
 * Email: egarcia3266@alumno.uned.es
 * DNI: 54487155V
 * Versión: 1.0
 */
public class Sentencia extends NonTerminal {

    /** Constructor por defecto */
    public Sentencia() {
        super();
    }

    /**
     * Constructor de copia
     * 
     * @param other otra instancia de Sentencia
     */
    public Sentencia(Sentencia other) {
        super();
    }
}
