package compiler.syntax.nonTerminal;

import es.uned.lsi.compiler.semantic.type.TypeIF;

/**
 * Clase que representa una declaración de tipo en el compilador AdaUNED.
 * Puede ser un tipo simple, enumerado, array, registro, etc.
 * 
 * Autor: Eduardo Garcia Romera
 * Email: egarcia3266@alumno.uned.es
 * DNI: 54487155V
 * Versión: 1.0
 */
public class DeclTipos extends NonTerminal {

    /** Tipo definido por el usuario */
    private TypeIF type;

    /** Constructor por defecto */
    public DeclTipos() {
        super();
    }

    /**
     * Constructor con parámetro de tipo
     * 
     * @param type tipo definido
     */
    public DeclTipos(TypeIF type) {
        super();
        this.type = type;
    }

    /**
     * Constructor de copia
     * 
     * @param other otra instancia de DeclTipos
     */
    public DeclTipos(DeclTipos other) {
        super();
        this.type = other.type;
    }

    public TypeIF getType() {
        return type;
    }

    public void setType(TypeIF type) {
        this.type = type;
    }
}
