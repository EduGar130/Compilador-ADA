package compiler.syntax.nonTerminal;

import es.uned.lsi.compiler.intermediate.TemporalIF;
import es.uned.lsi.compiler.semantic.type.TypeIF;

/**
 * Clase que representa una sentencia RETURN en el compilador AdaUNED.
 * Contiene el temporal del valor devuelto y su tipo.
 * 
 * Autor: Eduardo Garcia Romera
 * Email: egarcia3266@alumno.uned.es
 * DNI: 54487155V
 * Versión: 1.0
 */
public class SentenciaReturn extends NonTerminal {

    /** Temporal con el valor de retorno */
    private TemporalIF temporal;

    /** Tipo del valor retornado */
    private TypeIF type;

    /** Constructor por defecto */
    public SentenciaReturn() {
        super();
    }

    /**
     * Constructor con temporal y tipo
     * 
     * @param temporal temporal que contiene el valor de retorno
     * @param type     tipo del valor retornado
     */
    public SentenciaReturn(TemporalIF temporal, TypeIF type) {
        super();
        this.temporal = temporal;
        this.type = type;
    }

    /**
     * Constructor de copia
     * 
     * @param other otra instancia de SentenciaReturn
     */
    public SentenciaReturn(SentenciaReturn other) {
        super();
        this.temporal = other.temporal;
        this.type = other.type;
    }

    public TemporalIF getTemporal() {
        return temporal;
    }

    public void setTemporal(TemporalIF temporal) {
        this.temporal = temporal;
    }

    public TypeIF getType() {
        return type;
    }

    public void setType(TypeIF type) {
        this.type = type;
    }
}
