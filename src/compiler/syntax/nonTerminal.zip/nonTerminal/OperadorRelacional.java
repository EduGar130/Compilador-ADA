package compiler.syntax.nonTerminal;

/**
 * Clase que representa un operador relacional en el compilador AdaUNED.
 * Contiene el símbolo del operador (ej: =, /=, <, <=, >, >=).
 * 
 * Autor: Eduardo Garcia Romera
 * Email: egarcia3266@alumno.uned.es
 * DNI: 54487155V
 * Versión: 1.0
 */
public class OperadorRelacional extends NonTerminal {

    /** Símbolo del operador relacional */
    private String operador;

    /** Constructor por defecto */
    public OperadorRelacional() {
        super();
    }

    /**
     * Constructor con símbolo
     * 
     * @param operador símbolo del operador relacional
     */
    public OperadorRelacional(String operador) {
        super();
        this.operador = operador;
    }

    /**
     * Constructor de copia
     * 
     * @param other otra instancia de OperadorRelacional
     */
    public OperadorRelacional(OperadorRelacional other) {
        super();
        this.operador = other.operador;
    }

    public String getOperador() {
        return operador;
    }

    public void setOperador(String operador) {
        this.operador = operador;
    }
}
