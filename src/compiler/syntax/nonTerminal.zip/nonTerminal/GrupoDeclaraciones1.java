package compiler.syntax.nonTerminal;

/**
 * Clase que representa el primer grupo de declaraciones (constantes) del
 * compilador AdaUNED.
 * 
 * Autor: Eduardo Garcia Romera
 * Email: egarcia3266@alumno.uned.es
 * DNI: 54487155V
 * Versión: 1.0
 */
public class GrupoDeclaraciones1 extends NonTerminal {

    public GrupoDeclaraciones1() {
        super();
    }

    public GrupoDeclaraciones1(GrupoDeclaraciones1 other) {
        super();
    }
}
