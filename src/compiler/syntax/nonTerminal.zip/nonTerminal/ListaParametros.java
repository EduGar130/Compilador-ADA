package compiler.syntax.nonTerminal;

import compiler.semantic.symbol.SymbolParameter;

import java.util.ArrayList;
import java.util.List;

/**
 * Clase que representa una lista de parámetros en el compilador AdaUNED.
 * Acumula los parámetros definidos en una función o procedimiento.
 * 
 * Autor: Eduardo Garcia Romera
 * Email: egarcia3266@alumno.uned.es
 * DNI: 54487155V
 * Versión: 1.0
 */
public class ListaParametros extends NonTerminal {

    /** Lista de parámetros */
    private List<SymbolParameter> parametros;

    /** Constructor por defecto */
    public ListaParametros() {
        super();
        this.parametros = new ArrayList<>();
    }

    /**
     * Constructor con lista de parámetros
     * 
     * @param parametros lista de parámetros
     */
    public ListaParametros(List<SymbolParameter> parametros) {
        super();
        this.parametros = parametros;
    }

    /**
     * Constructor de copia
     * 
     * @param other otra instancia de ListaParametros
     */
    public ListaParametros(ListaParametros other) {
        super();
        this.parametros = new ArrayList<>(other.parametros);
    }

    public List<SymbolParameter> getParametros() {
        return parametros;
    }

    public void setParametros(List<SymbolParameter> parametros) {
        this.parametros = parametros;
    }

    /**
     * Añade un parámetro a la lista.
     * 
     * @param parametro el parámetro a añadir
     */
    public void addParametro(SymbolParameter parametro) {
        this.parametros.add(parametro);
    }
}
