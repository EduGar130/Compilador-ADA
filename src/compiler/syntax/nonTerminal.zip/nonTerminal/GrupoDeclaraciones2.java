package compiler.syntax.nonTerminal;

/**
 * Clase que representa el segundo grupo de declaraciones (tipos) del compilador
 * AdaUNED.
 * 
 * Autor: Eduardo Garcia Romera
 * Email: egarcia3266@alumno.uned.es
 * DNI: 54487155V
 * Versión: 1.0
 */
public class GrupoDeclaraciones2 extends NonTerminal {

    public GrupoDeclaraciones2() {
        super();
    }

    public GrupoDeclaraciones2(GrupoDeclaraciones2 other) {
        super();
    }
}
